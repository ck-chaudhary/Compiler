rm token.list
clear
echo "Compiling..."
g++ -std=c++11 dfa.cpp
clear
python dfa.py $1
./a.out
rm .temp.dat

