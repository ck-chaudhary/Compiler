#include <iostream>
#include <fstream>
#include <stdio.h>

using namespace std;

/* Multiline
   Comment */

int main () {
	int a , d;		// single line comment
	int b;
	int c;
	float x;
	a = 10.4.4;
	b = 5;
	c = a + b;
	cout << c;

	x = 10.24;

	if ( c == 1 ) {
		switch ( c ) {
			default: cout << "10.4 is the problem string";
		}
	}
	cout << "This string is recognised!" << a << "And Also this";
//        cout << "Single string" << a;	
	cout << "Double string";
	scanf ( "%c" , &c );
	return 1;
}

