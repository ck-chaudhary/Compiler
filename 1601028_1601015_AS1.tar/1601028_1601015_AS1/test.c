/*int main ( ) {
int a , b , c , i ;
a = 45 ;
b = 8 ;
c = a + b + c ;
for ( i = 0 ; i < 50 ; i ++ ) {
  if ( i % 2 == 0) {
    a = 0 ;
  } else {
    a = 1 ;
  }

}
  return 0 ;
}*/

int x = 8 ;
int globeSum ( int , int ) ;
int main ( ) {
int a , b , i ;
float c ;
a = 45 ;
b = 8 ;
c = ( ( float ) a ) + ( ( float ) b ) * c ;
( float ) x = ( float ) x + 7.4 ;
for ( i = 0 ; i < 50 ; i ++ ) {
if ( i % 2 == 0 ) {
a = 0 ;
} else {
a = 1 ;
}
}
i = globeSum ( a , b ) ;
return 0 ;
}
int globeSum ( int x , int y ) {
int sum ;
sum = x + y ;
return sum ;
}
