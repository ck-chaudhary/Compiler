g++ tem.cpp
./a.out
