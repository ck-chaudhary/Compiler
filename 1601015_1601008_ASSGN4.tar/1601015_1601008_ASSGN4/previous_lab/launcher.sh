
lex subc.l
yacc -d subc.y
gcc lex.yy.c y.tab.c -o subc
./subc

rm lex.yy.c
rm y.tab.c
rm subc
rm y.tab.h
