lex calc_type.l
yacc -d calc_type.y
gcc lex.yy.c y.tab.c -o calc_type
./calc_type
