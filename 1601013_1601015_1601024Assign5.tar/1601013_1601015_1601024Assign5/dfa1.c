#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include"symbtab.c"
void operator(char *);
void delimiter(char *);
void comment_remove(FILE *);
extern char type[10][10];
void litral(FILE *fp);
struct typeid
{
  char name[10];
  char type[10];
};

struct typeid arr[50];
int count=0,counter=0;
char array[100][20],stri[50];

FILE *f;

void isIdentifier(char *buf)
{
  if(buf[0]=='_' || buf[0]>64&&buf[0]<91 || buf[0]>96&&buf[0]<123)
  {
    strcpy(arr[0].name,buf);
    count++;
  }
  else
    operator(buf);
}

void function(char *buf)
{
  char *token;
  token=strtok(buf," ");
  char func_name[10];
  int argcount=0;
  strcpy(func_name,token);
  while(token!=NULL)
  {
  //  printf("Hi\n" );
    if(!(strcmp(token,"int")&&strcmp(token,"float")&&strcmp(token,"char")))
    {
      strcat(stri,token);
      strcat(stri," ");
      argcount++;
    }
    token=strtok(NULL," ");
    if(!(strcmp(token,";\n")&&strcmp(token,");\n")&&strcmp(token,"{\n")&&strcmp(token,")\n")))
    break;
  }
  searchgt(func_name,argcount);

// printf("dectype->%s\n",stri);
//  printf("types->%s\n",type[0]);
  int i=0;
  char *broken;
  broken=strtok(stri," ");
  while(i++ <= argcount){
  //  printf("broken->%s\n",broken);
  //  printf("type->%s\n",type[i-1]);
    if(strcmp(broken,type[i-1])==0){
    //  printf("HI\n");
      broken=strtok(NULL," ");
      continue;
    }

      else{
        broken=strtok(NULL," ");
    if(i==1){
      printf("\n!!! Return Type of %s is not matching \n",func_name);
    }
    else
      printf("\n!!! Parameter Type of %s is not matching \n",func_name);

  }
}
}
void IsNumber(char *buf)
{
  char state='S';
  int i=0,f=0,flag=0;
  char c;
  c=buf[0];
while((c>47 && c<58)||c=='.')
{
  if(c=='.')
   flag=1;
  if(i>=strlen(buf))
    break;
  state='F';
  c=buf[i];
  i++;
}
if(state=='F' && i==strlen(buf) && flag==0)
  {
    strcat(buf," Integer");
    strcpy(array[counter],buf);
    counter++;
  }
else if(state=='F' && i==strlen(buf) && flag==1)
  {
    strcat(buf," Float");
    strcpy(array[counter],buf);
    counter++;
  }
}
void delimiter(char *buf)
{
  int i;
  char c;
  char state='S';
  for(i=0;i<strlen(buf);i++)
  {
    c=buf[i];
    if(state=='S' && c=='{')
      state='F';
    else if(state=='S' && c=='}')
      state='F';
    else if(state=='S' && c=='(')
      state='F';
    else if(state=='S' && c==')')
      state='F';
    else if(state=='S' && c==';')
      state='F';
    else if(state=='S' && c==',')
      state='F';
    else if(state=='F' && c==')')
      state='F';
    else if(state=='F' && c!=')' && i<strlen(buf))
        {
          state='S';
          break;
        }
  }
  if(state=='F')
    {
      strcat(buf," Delimiter");
      strcpy(array[counter],buf);
      counter++;
    }
  else
    IsNumber(buf);

}
void operator(char *buf)
{
  int i;
  char c;
  char state='S';
  for(i=0;i<strlen(buf);i++)
  {
    c=buf[i];
    if(state=='S' && c=='=')
      state='F';
    else if(state=='S' && c=='+')
      state='F';
    else if(state=='S' && c=='-')
      state='F';
    else if(state=='S' && c=='*')
        state='F';
    else if(state=='S' && c=='/')
        state='F';
    else if(state=='S' && c=='>')
        state='F';
    else if(state=='S' && c=='<')
        state='F';
    else if(state=='F' && c=='=')
        state='F';
    else if(state=='S' && c=='!')
          state='F';
    else if(state=='F' && c!='=' && i<strlen(buf))
    {
        state='S';
        break;
    }
  }
  if(state=='F')
  {
    strcat(buf," Operator");
    strcpy(array[counter],buf);
    counter++;
  }

  else
    delimiter(buf);
}
int main()
{
  abc();
char buf[10],copy[10],buffer[250];
int i;
char c,state,k,*token;
FILE *fp;
f=fopen("compile.txt","w");
fp=fopen("inp2.txt","r+");
comment_remove(fp);
fseek(fp, 0, SEEK_SET);
while(fscanf(fp,"%s",buf)!=EOF)
{
  i=0;
  state='S';
  for(i=0;i<strlen(buf);i++)
  {
    c=buf[i];

    if(state=='S' && c=='i')
      state='A';
    else if(state=='F' && i<(strlen(buf)))
    {
      state='S';
      break;
    }

    else if(state=='A' && c=='n')
      state='B';
    else if(state=='A' && c=='f')
      state='F';
    else if(state=='B' && c=='t')
      state='F';
    else if(state=='C' && c=='l')
      state = 'D';
    else if(state=='D' && c=='s')
      state = 'E';
    else if(state=='E' && c=='e')
      state='F';
    else if(state=='G' && c=='a')
      state = 'H';
    else if(state=='G' && c=='h')
      state = 'N';
    else if(state=='H' && c=='s')
      state = 'I';
    else if(state=='I' && c=='e')
      state='F';
    else if(state=='J' && c=='i')
      state='K';
    else if(state=='K' && c=='t')
        state='L';
    else if(state=='L' && c=='c')
        state='M';
    else if(state=='M' && c=='h')
        state='F';
    else if(state=='N' && c=='a')
      state='U';
    else if(state=='S' && c=='f')
      state='O';
    else if(state=='S' && c=='c')
      state='G';
    else if(state=='O' && c=='l')
      state='T';
    else if(state=='T' && c=='o')
      state='P';
    else if(state=='P' && c=='a')
      state='Q';
    else if(state=='Q' && c=='t')
      state='F';
    else if(state=='R' && c=='w')
      state='J';
    else if(state=='S' && c=='s')
      state='R';
    else if(state=='R' && c=='t')
      state='V';
    else if(state=='S' && c=='e')
      state='C';
    else if(state=='U' && c=='r')
      state='F';
    else if(state=='V' && c=='r')
      state='W';
    else if(state=='W' && c=='u')
      state='X';
    else if(state=='X' && c=='c')
      state='Y';
    else if(state=='Y' && c=='t')
      state='F';
  }
  if(state=='F' && i>=strlen(buf))
  {
    if(!(strcmp(buf,"int")&&strcmp(buf,"float")&&strcmp(buf,"char")))
    {
        strcpy(copy,buf);

        fgets(buffer,250,fp);
        //printf("buffer->%s\n",buffer);
        if(buffer[strlen(buffer)-2]==';'&& buffer[strlen(buffer)-4]==')'||buffer[strlen(buffer)-2]==')'||buffer[strlen(buffer)-2]=='{')
        {

          strcpy(stri,"");
          strcat(stri,copy);
          strcat(stri," ");
          function(buffer);

        }
        else
        {

          token=strtok(buffer," ,");

          while(token!=NULL)
          {

        if(token[0]=='_' || token[0]>64 && token[0]<91 || token[0]>96 && token[0]<123)
        {
        if((strcmp(token,"int")&&strcmp(token,"float")&&strcmp(token,"char")))
        {
          strcpy(arr[count].type,copy);
          strcpy(arr[count].name,token);
            count++;
        }
        }
        token=strtok(NULL," ,");
        if(!strcmp(token,";\n"))
        break;
      }
      }
    }
    else
    {
      strcat(buf," Key-word");
      strcpy(array[counter],buf);
      counter++;
    }
  }
  else if(strcmp(buf,"printf(")==0||strcmp(buf,"scanf(")==0)
  {
    litral(fp);
  }
  else
    operator(buf);
}
fclose(fp);
for(i=0;i<=counter;i++)
{
  fprintf(f,"%s\n",array[i]);
}
fprintf(f,"%s","Name\tType\tSize\n\n");
for(i=0;i<=count;i++)
{

  fprintf(f,"%s\t",arr[i].name);
  fprintf(f,"%s\t",arr[i].type);

  if(strcmp(arr[i].type,"int")==0)
    fprintf(f, "%ld\n",sizeof(int));
  else if(strcmp(arr[i].type,"char")==0)
    fprintf(f, "%ld\n",sizeof(char));
  else if(strcmp(arr[i].type,"float")==0)
    fprintf(f, "%ld\n",sizeof(float));
}
fclose(f);
return 0;
}



void comment_remove(FILE *tp1)
{
 char buff[250],buf[20],d;
 int c,count,j;

 while((c=fgetc(tp1))!=EOF)
{
  	if((char)c=='/')
    {
        if(fgetc(tp1)=='/')
	      {
            fseek(tp1, -2, SEEK_CUR);
            while(fgets(buff,250,tp1))
            {
                j=strlen(buff);
                fseek(tp1, -j, SEEK_CUR);
                count=0;
                while(count<(strlen(buff)-1))
                {
                    fprintf(tp1,"%c",' ');
                    count++;
                }
                if(buff[strlen(buff)-1]=='\n')
                {
                  printf("hi\n");
                  break;
              }
          }
	     }
       fseek(tp1, -1, SEEK_CUR);
	     if(fgetc(tp1)=='*')
	     {
          fseek(tp1, -2, SEEK_CUR);
          while(fgets(buff,250,tp1))
          {
              j=strlen(buff);
              fseek(tp1, -j, SEEK_CUR);
              count=0;
              while(count<(strlen(buff)-1))
              {
                  fprintf(tp1,"%c",' ');
                  count++;
              }
              if(buff[strlen(buff)-2]=='/' && buff[strlen(buff)-3]=='*')
              {
                  break;
              }
              fgetc(tp1);
  	     }
       }
     }

   }
}


void litral(FILE *fp)
{
char d;
fprintf(f,"%s","Litral: ");
  d=fgetc(fp);
  if((d=fgetc(fp))=='"')
  {
    while(d=fgetc(fp))
    {
       if(d=='"')
         break;
       fprintf(f,"%c",d);
     }
   fprintf(f,"%s","\n");
  }

}
