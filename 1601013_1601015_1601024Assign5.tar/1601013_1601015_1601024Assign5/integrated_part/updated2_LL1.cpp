  #include <cstdio>
#include <cstring>
#include <string>
#include <vector>
#include <iostream>
#include <ctime>
#include <sstream>
#include <stack>
#include <fstream>
#include <ostream>
using  namespace std;
#define rows  12
#define  cols 19

vector< vector<string> >  Parse_Table(rows, vector<string>(cols));


template <class Container, class Stream>
Stream& printOneValueContainer
    (Stream& outputstream, const Container& container)
{
    typename Container::const_iterator beg = container.begin();

    outputstream << "[";

    while(beg != container.end())
    {
        outputstream << " " << *beg++;
    }

    outputstream << " ]";

    return outputstream;
}

template < class Type, class Container >
const Container& container
    (const std::stack<Type, Container>& stack)
{
    struct HackedStack : private std::stack<Type, Container>
    {
        static const Container& container
            (const std::stack<Type, Container>& stack)
        {
            return stack.*&HackedStack::c;
        }
    };

    return HackedStack::container(stack);
}


template
    < class Type
    , template <class Type, class Container = std::deque<Type> > class Adapter
    , class Stream
    >
Stream& operator<<
    (Stream& outputstream, const Adapter<Type>& adapter)
{
    return printOneValueContainer(outputstream, container(adapter));
}

bool is_terminal(string s){
	bool found=false;
	for (size_t i = 0; i < cols; i++) {
		if(Parse_Table[0][i].compare(s)==0)
		found=true;
	}
	return found;
}

int main(void)
{

	stack <string> my_stack;
  my_stack.push("$");

	//above code for manual implimentation of parse table
Parse_Table[0][0]="TABLE";
Parse_Table[0][1]="type";
Parse_Table[0][2]="id";
Parse_Table[0][3]="(";
Parse_Table[0][4]=")";
Parse_Table[0][5]="return";
Parse_Table[0][6]="if";
Parse_Table[0][7]="for";
Parse_Table[0][8]="op";
Parse_Table[0][9]="cond_op";
Parse_Table[0][10]="++";
Parse_Table[0][11]="--";
Parse_Table[0][12]="else";
Parse_Table[0][13]=";";
Parse_Table[0][14]="}";
Parse_Table[0][15]="{";
Parse_Table[0][16]="lit";
Parse_Table[0][17]=",";
Parse_Table[1][0]="MD";
Parse_Table[2][0]="F";
Parse_Table[3][0]="STMTS";
Parse_Table[4][0]="JOB";
Parse_Table[5][0]="EXPR";
Parse_Table[6][0]="C_E";
Parse_Table[7][0]="FOR_LOOP";
Parse_Table[8][0]="INR";
Parse_Table[9][0]="COND";
Parse_Table[10][0]="CA";
Parse_Table[11][0]="RET";
Parse_Table[0][18]="$";

	for(int i = 1; i < rows; i++){
	      for(int j = 1; j < cols; j++){
                 if(i==1 && j==1)
                   Parse_Table[i][j]= "MD type id F";
                 else if(i==2 && j==3)
		  			 			 Parse_Table[i][j]= "F ( ) { STMTS }";
                 else if(i==3 && j==1)
                   Parse_Table[i][j]= "STMTS MD";
                else if(i==3 && j==2)
                   Parse_Table[i][j]= "STMTS JOB";
								else if(i==3 && j==5)
                   Parse_Table[i][j]= "STMTS RET";
								else if(i==3 && j==6)
                   Parse_Table[i][j]= "STMTS COND";
								else if(i==3 && j==7)
                   Parse_Table[i][j]= "STMTS FOR_LOOP";
								else if(i==4 && j==2)
                   Parse_Table[i][j]= "JOB id EXPR ;";
                else if(i==5 && j==8)
                   Parse_Table[i][j]= "EXPR op ( ( type ) id ) EXPR ";
								else if(i==6 && j==9)
                   Parse_Table[i][j]= "C_E cond_op lit";
								else if(i==7 && j==7)
                   Parse_Table[i][j]= "FOR_LOOP for ( id EXPR ; id C_E ; id INR ) { STMTS }";
								else if(i==8 && j==10)
                   Parse_Table[i][j]= "INR ++";
                else if(i==8 && j==11)
                   Parse_Table[i][j]= "INR --";
								else if(i==9 && j==6)
                   Parse_Table[i][j]= "COND if ( id EXPR cond_op lit ) { STMTS } CA";
								else if(i==10 && j==12)
                   Parse_Table[i][j]= "CA else { STMTS }";
								else if(i==10 && j==14)
                   Parse_Table[i][j]= "CA null";
								else if(i==11 && j==5)
                   Parse_Table[i][j]= "RET return lit ;";
		 						else
		  						Parse_Table[i][j]="Err";
	     }
	}
	for(int i = 0; i < rows; i++){
		cout<<"________________________________________________________________________________________________________________________________________________________________________________________________________________________________";
		for(int j = 0; j < cols; j++){
		//	if(Parse_Table[i][j].compare("Err")!=0)
			cout<< Parse_Table[i][j];
                        printf("\t");
		}
		printf("\n");
	}

/* Actual processing
*/
string buf,input;
ifstream f;
f.open("inp.txt");
if(!f){
	cout<< "\nsome error while file opening\n";
	return 0;
}
string  inp;
f.seekg(0,ios::end);
//cout <<"File size :\t"<< f.tellg()<<endl;
int file_size=f.tellg();
f.seekg(0,ios::beg);
//cout <<"File size :\t"<< f.tellg()<<endl;
while(!f.eof()){
f >> inp;
//	cout <<"\nfile checking:\t"<< f.tellg()<<endl;
	if(f.tellg() == -1)
	break;
//cout<<inp<<endl;
inp.append(" ");
//inp.append("$");
input.append(inp);
//cout<<"\n going to append :\t"<<inp<<endl;
//cout<<iGoing np<<"\t"<<input<<endl;
if(f.tellg() == file_size-1)
break;
}
input.append("$");
cout<<"\n input output"<<input<<endl;

cout <<"\n\n\n\t Input to be parsed\n\t\t.\n\t\t.\n\t\t.\n\t\t.\n\t\t.\n\t\t.\n\t\t.\n\t\t.\n\t\t.\n\t\t.\n\t\t.\n\t\t.\n"<< input<<endl;
 // input="type id ( ) { type id , id , id , id ; id op lit ; for ( id op lit ; id cond_op lit ; id ++ ) { id op lit ; if ( id op lit cond_op lit ) { id op lit ; } else { id op lit ; } } if ( id op lit cond_op lit ) { id op lit ; } else { id op lit ; } return lit ;  }";
//input="type id , id , id , id ;";
//cout << input<<endl;
//="id op id op id op id ;";
/*input="type id ( ) { id op id op id op id ; id op lit ; id op lit ; for ( id op lit ; id cond_op lit ; id ++ ) { if ( id op lit cond_op lit ) { id op lit ; } else { id op lit ; } } return lit ; }";*/
stringstream ss(input);
string buff;
int first_symbol=0;
int col_no;
string production;
stack <string> temp_stack;
int size_temp_stack,error_state=0;
string buff1;
time_t current_time,start_time=time(NULL);



while (ss >> buff) {
//cout<<"\n Start time :\t"<<start_time<<endl;
//cout<<"\n current time :\t"<<time(NULL)<<endl;
current_time=time(NULL);
if(current_time-start_time > 0)
break;

	if(error_state){
		break;
	}
if(buff.compare("type")==0){
  int pos=ss.tellg();
  string lookahead;
  ss >> lookahead;

  ss >> lookahead;
  //cout << "lookahead :\t"<<lookahead<<endl;
if(lookahead.compare("op")==0 && buff.compare("type")==0){
  Parse_Table[1][1]= "MD type id EXPR ;";
  cout<<"\n\tTable entry changed for MD(EXPR)"<<endl;
 }

 else if(lookahead.compare(",")==0 && buff.compare("type")==0){
  Parse_Table[1][1]= "MD type id , id , id , id ;";
  cout<<"\n\tTable entry changed for MD->id"<<endl;
}
else if(lookahead.compare("(")==0 && buff.compare("type")==0){
  Parse_Table[1][1]= "MD type id F";
  cout<<"\n\tTable entry changed for MD-> F"<<endl;
}
ss.seekg(pos,ios::beg);
}



if(buff.compare("op")==0){
  int pos=ss.tellg();
  string lookahead;
  ss >> lookahead;
  int flg=0;
  //printf("printing first lookahead for op=%s",lookahead);
  cout<<"printing first lookahead for op="<<lookahead<<endl;

  if(lookahead.compare("id")==0 || lookahead.compare("lit")==0){
    if(lookahead.compare("id")==0 && buff.compare("op")==0){
    Parse_Table[5][8]= "EXPR op id";
    cout<<"\n\tTable entry changed to id"<<endl;
    flg=1;
    ss>>lookahead;
    if(lookahead.compare("(")==0){
      Parse_Table[5][8]= "EXPR op id ( id , id )";
      cout<<"\n\tTable entry changed to function call"<<endl;
    }
  }
    else if(lookahead.compare("lit")==0 && buff.compare("op")==0){
    Parse_Table[5][8]= "EXPR op lit";
    cout<<"\n\tTable entry changed to lit"<<endl;
    flg=1;
  }
}
//  printf("printing first lookahead for op=%s",lookahead);

  ss>>lookahead;
    cout<<"printing second lookahead for op="<<lookahead<<endl;
if(lookahead.compare("(")==0 && flg==0 ){
  Parse_Table[5][8]= "EXPR op ( ( type ) id ) EXPR ";
  cout<<"\n\tTable entry changed to type casting"<<endl;
}
else if(lookahead.compare("type")==0 && flg==0){
Parse_Table[5][8]= "EXPR op ( type ) id  EXPR ";
cout<<"\n\tTable entry changed to type casting"<<endl;
}



ss.seekg(pos,ios::beg);
}

if(buff.compare("(")==0){
  int pos=ss.tellg();
  string lookahead;
  ss >> lookahead;

  ss >> lookahead;

  if(lookahead.compare("{")==0 && buff.compare("(")==0){
   Parse_Table[2][3]= "F ( ) { STMTS }";
   cout<<"\n\tTable entry changed for F"<<endl;
 }
 else if(lookahead.compare(",")==0 && buff.compare("(")==0){
  Parse_Table[2][3]= "F ( type , type ) ;";
  cout<<"\n\tTable entry changed for F"<<endl;
 }
 else if(lookahead.compare("id")==0 && buff.compare("(")==0){
  Parse_Table[2][3]= "F ( type id , type id ) { STMTS }";
  cout<<"\n\tTable entry changed for F"<<endl;
 }
 else if(lookahead.compare(")")==0 && buff.compare("(")==0){
  Parse_Table[2][3]= "F ( type ) id EXPR ;";
  cout<<"\n\tTable entry changed for F->typecasting"<<endl;
 }
ss.seekg(pos,ios::beg);
}

if(buff.compare("id")==0){
  int pos=ss.tellg();
  string lookahead;
  ss >> lookahead;

  if(lookahead.compare("op")==0 && buff.compare("id")==0){
   Parse_Table[4][2]= "JOB id EXPR ;";
   cout<<"\n\tTable entry changed for JOB"<<endl;
 }
//  else if(lookahead.compare("(")==0 && buff.compare("id")==0){
//   Parse_Table[4][2]= "JOB id ( id , id ) ;";
//   cout<<"\n\tTable entry changed for JOB"<<endl;
// }

ss.seekg(pos,ios::beg);

}

if(buff.compare("return")==0){
  int pos=ss.tellg();
  string lookahead;
  ss >> lookahead;

  if(lookahead.compare("id")==0 && buff.compare("return")==0){
   Parse_Table[11][5]= "RET return id ;";
   cout<<"\n\tTable entry changed for return->id"<<endl;
 }
 else if(lookahead.compare("lit")==0 && buff.compare("return")==0){
  Parse_Table[11][5]= "RET return lit ;";
  cout<<"\n\tTable entry changed for return->lit"<<endl;
}

ss.seekg(pos,ios::beg);

}

//
//
// 	if(buff.compare("op")==0 || buff.compare("type")==0 || buff.compare("(") || buff.compare("id")){
// 	 // changing input in parsing table...........
//   //  cout <<"Postion of op:\t"<< ss.tellg()<<endl;
//     int pos=ss.tellg();
//     string lookahead;
//     ss >> lookahead;
//   //  cout << "lookahead :\t"<<lookahead<<endl;
//
//   //  cout <<"Restored Postion of op:\t"<< ss.tellg()<<endl;
//   if(lookahead.compare("op")==0 && buff.compare("id")==0){
//    Parse_Table[4][2]= "JOB id EXPR ;";
//    cout<<"\n\tTable entry changed for JOB"<<endl;
//  }
//  else if(lookahead.compare("(")==0 && buff.compare("id")==0){
//   Parse_Table[4][2]= "JOB id ( id , id ) ;";
//   cout<<"\n\tTable entry changed for JOB"<<endl;
// }
//
//     if((lookahead.compare("id")==0 || lookahead.compare("lit")==0) && buff.compare("op")==0){
//       if(lookahead.compare("id")==0 && buff.compare("op")==0){
//       Parse_Table[5][8]= "EXPR op id";
//       cout<<"\n\tTable entry changed to id"<<endl;
//     }
//       else if(lookahead.compare("lit")==0 && buff.compare("op")==0){
//       Parse_Table[5][8]= "EXPR op lit";
//       cout<<"\n\tTable entry changed to lit"<<endl;
//     }
//     ss>>lookahead;
//     if(lookahead.compare("(")==0 && buff.compare("op")==0){
//     Parse_Table[5][8]= "EXPR op ( ( type ) id ) EXPR ;";
//     cout<<"\n\tTable entry changed to type casting"<<endl;
//   }
// else if(lookahead.compare("type")==0 && buff.compare("op")==0){
//   Parse_Table[5][8]= "EXPR op ( type ) id  EXPR ;";
//   cout<<"\n\tTable entry changed to type casting"<<endl;
// }
//
//   }
//
// 	ss >> lookahead;
// 	//cout << "lookahead :\t"<<lookahead<<endl;
// if(lookahead.compare("op")==0 && buff.compare("type")==0){
//  	Parse_Table[1][1]= "MD type id EXPR ;";
//  	cout<<"\n\tTable entry changed for MD"<<endl;
//  }
//
//  else if(lookahead.compare(",")==0 && buff.compare("type")==0){
// 	Parse_Table[1][1]= "MD type id , id , id , id ;";
// 	cout<<"\n\tTable entry changed for MD"<<endl;
// }
// else if(lookahead.compare("(")==0 && buff.compare("type")==0){
//   Parse_Table[1][1]= "MD type id F";
//   cout<<"\n\tTable entry changed for MD"<<endl;
// }
//
//
//  if(lookahead.compare("{")==0 && buff.compare("(")==0){
//   Parse_Table[2][3]= "F ( ) { STMTS }";
//   cout<<"\n\tTable entry changed for F"<<endl;
// }
// else if(lookahead.compare(",")==0 && buff.compare("(")==0){
//  Parse_Table[2][3]= "F ( type , type ) ;";
//  cout<<"\n\tTable entry changed for F"<<endl;
// }
// else if(lookahead.compare("id")==0 && buff.compare("(")==0){
//  Parse_Table[2][3]= "F ( type id , type id ) { STMTS }";
//  cout<<"\n\tTable entry changed for F"<<endl;
// }
//
//
//
// //cout <<"\nRestored Postion of op:\t"<< ss.tellg()<<endl;
// ss.seekg(pos,ios::beg);
// 	}
//
//   if(buff.compare("id")==0 || buff.compare("type")==0){
// 	 // changing input in parsing table...........
//   //  cout <<"Postion of op:\t"<< ss.tellg()<<endl;
//     int pos=ss.tellg();
//     string lookahead;
//     ss >> lookahead;
//   //  cout << "lookahead :\t"<<lookahead<<endl;
//
//   //  cout <<"Restored Postion of op:\t"<< ss.tellg()<<endl;
//
//     if(lookahead.compare("id")==0 && buff.compare("op")==0){
//     Parse_Table[5][8]= "EXPR op id";
//     cout<<"\n\tTable entry changed to id"<<endl;
//   }
//     else if(lookahead.compare("lit")==0 && buff.compare("op")==0){
//     Parse_Table[5][8]= "EXPR op lit";
//     cout<<"\n\tTable entry changed to lit"<<endl;
//   }
// 	ss >> lookahead;
// 	//cout << "lookahead :\t"<<lookahead<<endl;
//
//  if(lookahead.compare(",")==0 && buff.compare("type")==0){
// 	Parse_Table[1][1]= "MD type id , id , id , id ;";
// 	cout<<"\n\tTable entry changed for MD"<<endl;
// }
// else if(lookahead.compare("(")==0 && buff.compare("type")==0){
//   Parse_Table[1][1]= "MD type id F";
//   cout<<"\n\tTable entry changed for MD"<<endl;
// }
//
// //cout <<"\nRestored Postion of op:\t"<< ss.tellg()<<endl;
// ss.seekg(pos,ios::beg);
// 	}


if(first_symbol==0){
for (size_t i = 0; i < cols; i++) {
	if(buff.compare(Parse_Table[0][i]) == 0){
	col_no=i;
//	cout << i<< endl;
	first_symbol=1;
}
}

for (size_t i = 1; i < rows; i++) {

	if(Parse_Table[i][col_no].compare("Err")!=0){
	cout << Parse_Table[i][col_no]<<endl;
 production=Parse_Table[i][col_no];
	break;
}
else{
	error_state=1;
	break;
}

}
stringstream ss1(production);

while(ss1 >> buff1){
	temp_stack.push(buff1);
}
 size_temp_stack=temp_stack.size();
//cout<< size_temp_stack << endl;
while(--size_temp_stack > 0){
my_stack.push(temp_stack.top());
temp_stack.pop();
cout<<my_stack.top()<<endl;
}
temp_stack.pop();

}
int flag=0;
while(!my_stack.empty()){
  // if(time(NULL)-start_time > 0)
  // break;
	if(error_state){
    string st1,st2,st3;
    st1=my_stack.top();
    my_stack.pop();
    st2=my_stack.top();
    my_stack.pop();
    st3=my_stack.top();
		cout<<"\nError state reached while solving :\t"<<st1<<" "<<st2<<" "<<st3<<endl;
		break;
	}
  cout<<"\nbuffer pointer  : "<<buff<<endl;
	cout<< "Top of stack: "<<my_stack.top()<<endl;
if(is_terminal(my_stack.top())){
	//cout<< "terminal found at the top of stack\n"<<"buff="<<buff<<endl;
	if(my_stack.top().compare(buff)==0){
		cout<<"current stack size\t"<<my_stack.size()<<"\n\t\tpoping out symbol from stack :\t"<<my_stack.top()<<endl;
		my_stack.pop();
		break;
	}
  else {
		for (size_t i = 0; i < cols; i++) {
			if(buff.compare(Parse_Table[0][i]) == 0){
			col_no=i;
			cout <<i<< endl;
			first_symbol=1;
		}
		}
 int found=0;
		for (size_t i = 1; i < rows; i++) {
				cout << "____________searching entries_____________" <<Parse_Table[i][col_no]<<endl ;
			if(Parse_Table[i][col_no].compare("Err")!=0){
        found=1;
	//		cout << Parse_Table[i][col_no]<<endl;
		 production=Parse_Table[i][col_no];
			break;
		}

		}
    if(!found){
      error_state=1;

    }
		stringstream ss1(production);

		while(ss1 >> buff1){
			temp_stack.push(buff1);
		}
		 size_temp_stack=temp_stack.size();
		//cout<< size_temp_stack << endl;
		while(--size_temp_stack > 0){
		my_stack.push(temp_stack.top());
		temp_stack.pop();
		cout<<my_stack.top()<<endl;
		}
		temp_stack.pop();
	}
}

else{
	int row_no,colm_no;
for (size_t i = 0; i < rows; i++) {
//	cout<<"row["<<i<<"] : "<<Parse_Table[i][0]<<endl;
	if(Parse_Table[i][0].compare(my_stack.top())==0){
		row_no=i;
		break;
	}
}
for (size_t i = 0; i < cols; i++) {
//	cout<<"cols["<<i<<"] : "<<Parse_Table[0][i]<<endl;
	if(Parse_Table[0][i].compare(buff)==0){
colm_no=i;
break;
	}
}
if(Parse_Table[row_no][colm_no]!= "Err")
production=Parse_Table[row_no][colm_no];
else{
	error_state=1;
}
cout<<"\n....The new production to be processed.... :\t"<< production<<endl;
my_stack.pop();
stringstream ss2(production);
while(ss2 >> buff1){
	temp_stack.push(buff1);
}
size_temp_stack=temp_stack.size();
cout<<"\nsymbols putting into stack\n";
while(--size_temp_stack > 0){
my_stack.push(temp_stack.top());
temp_stack.pop();
cout<<my_stack.top()<<endl;
}
temp_stack.pop();
}
}
cout <<"\nPresent Stack \t"<< my_stack<<endl;
}

if(!error_state && my_stack.size()==0)
cout<<"\n\n*** Sucessfully Parsed ***\n\n";
else
cout<<"\n\n!!!! SOme Error occured !!!\n\n";
	return 0;
}
