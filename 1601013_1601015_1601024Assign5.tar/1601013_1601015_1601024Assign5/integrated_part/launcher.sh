rm token.list
rm inp.txt
clear
echo "Compiling... previous code for token generation...... "
g++ -std=c++11 dfa.cpp
clear
python dfa.py $1
./a.out
rm .temp.dat
echo "compiling ...LL(1) parser......"
echo
echo
echo
g++ -std=c++11 updated2_LL1.cpp
./a.out
