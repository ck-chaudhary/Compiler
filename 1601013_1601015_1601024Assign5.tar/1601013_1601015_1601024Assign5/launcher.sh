gcc dfa1.c
./a.out
