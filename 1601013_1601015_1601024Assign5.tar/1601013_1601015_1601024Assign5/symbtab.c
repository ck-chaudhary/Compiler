#include<stdio.h>
#include<stdlib.h>
#include<string.h>
int gtc=0,lc=0,ltc=0;
char type[10][10];
struct local{
char name[30];
char type[20];
char tag[20];
int  level;
}lsymtab[50],localvar;

struct globalt{
char name[30];
char res_type[10];
struct local *local_varptr;
int args;
int gvar_tag;
} gsymtab[10];

char * searchlt(char *ser)
{
  int i=0,f=0;
  while(i<lc)
  {
    if(!strcmp(lsymtab[i].name,ser))
    {
      f=1;
      return lsymtab[i].type;
    }
    i++;
  }
  if(lc==0||f==0)
  return "N";
}
char * searchgv(char *vname)
{
  int i=0,f=0;
  while(i<gtc)
  {
    if(!strcmp(vname,gsymtab[i].name))
    {
      f=1;
      return gsymtab[i].res_type;
    }

    i++;
  }
  if(gtc==0||f==0)
  return "N";
}
void searchgt(char *fname,int args)
{
  int i=0,f=0,c=0,j=0;
  struct local *p;
  //printf("name = %s, args = %d\n",fname,args);
  while(i<gtc)
  {

    if(!strcmp(gsymtab[i].name,fname))
    {
    f=1;

    strcpy(type[c++],gsymtab[i].res_type);

    p=gsymtab[i].local_varptr;
    //printf("pointer->%p\n",p);
    if(p!=NULL)
    {
    while (j<args)
    {
      strcpy(type[c++],p->type);
      //printf("name=%s\n",type[c]);
      //strcat(type[c]," ");
      //strcat(type[c++],p->type);
      p++;
      j++;
    }
  }

  //printf("type_array=%s\n",type[2]);
    }
    i++;
  }

}
struct local* localtablcall(struct local tem){
  char *ret;
  //
  ret=searchlt(tem.name);
  if(!strcmp(ret,"N"))
  {
    lsymtab[lc]=tem;
    //printf("Name->%s\n",tem.name);
    //printf("return1->%p\n",&lsymtab[lc]);
    return &lsymtab[lc++];

  }
  else
  {
    //printf("Hi,%s\n",tem.name);
    return NULL;
  }

  //printf("in ltable=%s\n",lsymtab[lc].name);
  // lsymtab[lc].name=tem.name;
  //   lsymtab[lc].type=tem.type;
  //     lsymtab[lc].tag=tem.tag;
  //       lsymtab[lc].level=tem.level;

}


void printlt(){
  int i=0;
  while(i < lc)
  {
    printf("%s\t",lsymtab[i].name);
    printf("%s\t",lsymtab[i].type);
    printf("%s\t",lsymtab[i].tag);
    printf("%d\n",lsymtab[i].level);
    i++;
  }

}


void printgt(){
  int i=0;
  while(i < gtc)
  {
    printf("%s\t",gsymtab[i].name);
    printf("%s\t",gsymtab[i].res_type);
    printf("%p\t",gsymtab[i].local_varptr);
    printf("%d\n",gsymtab[i].gvar_tag);
    i++;
  }

}

int abc()
{
  FILE *fp;
  char str[500],stng[500],*token,type[10],fname[20],tokcopy[20],v[20],*vr;
  int lev=0,paramc=0,flg=0,flag=0,f=0;
  char *typestored,typec[10];
  fp=fopen("inp2.txt","r");

  if(fp==NULL)
  {
    printf("File not found\n");
    return(-1);
  }
  else
  {

    while ( fgets(stng, 500, fp)!= NULL )
    {
      strcpy(str,stng);
      if(stng[strlen(stng)-2]=='{'||stng[0]=='{')
       lev++;
       if(stng[strlen(stng)-2]=='}'||stng[0]=='}')
        lev--;
 	   token=strtok(stng," ");
     if(!strcmp(token,"int")||!strcmp(token,"char")||!strcmp(token,"float")){
      strcpy(type,token);
      //printf("type=%s\n",type );
     if(str[strlen(str)-2]==';'&&str[strlen(str)-4]!=')')
     {
      while(token!=NULL)
     {
      token=strtok(NULL," ,");
      //printf("token=%s\n",token);
      //printf("token=%s,lev=%d\n",token,lev);
      if(!strcmp(token,";\n"))
        break;
      //printf("token for global_name=%s\n",token);
      if(token[0]>64&&token[0]<91||token[0]>97&&token[0]<123)
      {
      strcpy(gsymtab[gtc].name,token);
      //printf("Name=%s\n",token);
      strcpy(gsymtab[gtc].res_type,type);
      gsymtab[gtc].local_varptr=NULL;
      gsymtab[gtc].gvar_tag=1;
      gsymtab[gtc++].args=0;
      }
     }
    }

    else if(str[strlen(str)-2]==')'||str[strlen(str)-2]=='{')
    {

      token=strtok(NULL," ,");
      strcpy(fname,token);
      //printf("fname->%s\n",fname);
      strcpy(gsymtab[gtc].name,fname);
      strcpy(gsymtab[gtc].res_type,type);
      flg=0;
      //printf("flg->%d\n",flg);
      strcpy(localvar.tag,"in");
      while(token!=NULL)
      {
        token=strtok(NULL," ,");
        if(!(strcmp(token,"{")&&strcmp(token,")")))
          break;
      //  printf("token=%s,lev=%d\n",token,lev);

        if(!(strcmp(token,"int")&&strcmp(token,"char")&&strcmp(token,"float")))
        {
          strcpy(tokcopy,token);
          flag=1;
          paramc++;
        }
        if(flag==1)
        {
          //printf("Hi\n");
          token=strtok(NULL," ,");
          //printf("token=%s\n",token);
          if(token!=NULL)
          {
          //printf("token->%s\n",token);
          strcpy(localvar.name,token);
          strcpy(localvar.type,tokcopy);
          strcpy(localvar.tag,"par");
          localvar.level=lev-1 ;
          flag=0;
          }
        }
      //  printf("localvar->%s\n",localvar.name);
        struct local *ret;

        if(strcmp(localvar.name,"")&&strcmp(localvar.tag,"in"))
        {
          //printf("localvar->%s----\n",localvar.name);
          ret=localtablcall(localvar);
          f=1;
        }

          if(flg==0)
          {
            if(f==1)
            {
          //printf("Hi\n");
          //printf("return2->%p\n",ret);
          gsymtab[gtc].local_varptr=ret;
          flg=1;
          f=0;
        }
        }

      }
  int mbc=1;
  while(mbc)
    {

    fgets(stng, 500, fp);
    strcpy(str,stng);
    if(stng[strlen(stng)-2]=='{'||stng[0]=='{'){
      lev++;
      mbc++;
    }

     if(stng[strlen(stng)-2]=='}'||stng[0]=='}'){
       lev--;
       mbc--;
     }

   token=strtok(stng," ");
   if(!strcmp(token,"int")||!strcmp(token,"char")||!strcmp(token,"float")){
    strcpy(type,token);
   if(str[strlen(str)-2]==';')
   {
    while(token!=NULL)
   {

    token=strtok(NULL," ,");
    if(!strcmp(token,";\n"))
      break;

    if(token[0]>64&&token[0]<91||token[0]>96&&token[0]<123)
    {

    strcpy(localvar.name,token);
    strcpy(localvar.type,type);
    strcpy(localvar.tag,"var");
    localvar.level=lev;
    }
    //printf("localvar->%s\n",localvar.name);
    //printf("localvar->%s----\n",localvar.name);
    struct local *ret=localtablcall(localvar);
      if(flg==0)
      {
      //printf("return->%p\n",ret);
      gsymtab[gtc].local_varptr=ret;
      flg=1;
    }

   }

  }
}
else
{
  while(token!=NULL)
  {
  if(!strcmp(token,"int")||!strcmp(token,"char")||!strcmp(token,"float"))
  {
    strcpy(typec,token);
    token=strtok(NULL," ");
    if(!strcmp(token,")"))
    {
      token=strtok(NULL," ");
      typestored=searchlt(token);
      if(!strcmp(typestored,"N"))
          typestored=searchgv(token);
      if(strcmp(typestored,"N"))
        printf("%s is having type %s and it is typecasted to %s\n",token,typestored,typec);

    }
  }
  token=strtok(NULL," ");
}
}

    }
    gtc++;
  } //func closing
}
}
}
printlt();
printf("\nPrinting Global table\n");
printgt();
//searchgt("globeSum",2);
//printf("type_return->%s\n",type);
fclose(fp);
return 0;
}
