int main ( ) {
int a , b , c , i ;
a = 45 ;
b = 8 ;
c = a + b - c ;
for ( i = 0 ; i < 50 ; i ++ ) {
  if ( i % 2 == 0 ) {
    a = 0 ;
  } else {
    a = 1 ;
  }

}

if ( i % 2 >= 0 ) {
    a = 0 ;
  } else {
    for ( i = 0 ; i < 50 ; i ++ ) {
      if ( i % 2 == 0 ) {
        a = 0 ;
      } else {
        a = 1 ;
      }

    }
    a = 1 ;
}
c = i - a ;
  return 0 ;
}
