#include <iostream>
#include <fstream>
#include <vector>
#include <sstream>

using namespace std;
const int alpha_size = 1000;

struct trieNode {
	struct trieNode *children[alpha_size];
	bool isEnd;
};

struct trieNode *getNode (void) {
	struct trieNode *pNode = new trieNode;
	pNode->isEnd = false;
	for (int i = 0 ; i < alpha_size ; i++)
		pNode->children[i] = NULL;
	return pNode;
}

void insert (struct trieNode *root, string key)	{
	struct trieNode *pCrawl = root;
	for (int i = 0; i <key.length () ; i++) {
		int index = key[i] - '0';
		if (!pCrawl->children [index])
			pCrawl->children[index] = getNode ();
		pCrawl = pCrawl->children[index];
	}
	pCrawl->isEnd = true;
}

int search (struct trieNode *root, string key) {
	struct trieNode *traverse = root;
	for (unsigned i = 0 ; i < key.length () ; i++) {
		int index = key[i] - '0';
		if (!traverse->children[index])
			return false;
		traverse = traverse->children[index];
	}
	return (traverse != NULL && traverse->isEnd);
}

struct trieNode *keyword = getNode ();
struct trieNode *header = getNode ();
struct trieNode *operators = getNode ();
struct trieNode *brackets = getNode ();
struct trieNode *datatypes = getNode ();

vector <string> symbolTable;

bool symbolTableMethod (string var_name, string datatype, string size) {
	int flag = 0;
	string strA, strB;
	if (datatype == "NULLSTR") {
		for (auto a = symbolTable.begin (); a != symbolTable.end (); a++) {
			strA = *a, strB = *a;
			string temp = var_name;
			strA.erase (0, strA.find (",") + 1);
//			cout << strA << " " << temp << " " << " " << strA.substr (0,strA.find (",") + 1) << endl;
			if (temp == strA.substr (0,strA.find (","))) {
				flag = 1;
				break;
			}
			temp = "";
		}
	}
	else {
		datatype.append (",");
		datatype.append (var_name);
		datatype.append (",");
		datatype.append (size);
		symbolTable.push_back (datatype);
	}

	if (flag == 1)
		cout << "\t\t\t\t\t\t\tFrom Symbol Table:\t\t" << strB << endl;
	else
		cout << "\t\t\t\t\t\t\tEntered into the Symbol Table: \t\t" << datatype << endl;
	return true;
}

void symbolTablePrinter () {
	cout << "=======================================================================================================" << endl;
	cout << "  SYMBOL TABLE												" << endl;
	cout << "=======================================================================================================" << endl;
	cout << "\n" << endl;
	for (auto a = symbolTable.begin () ; a != symbolTable.end () ; a++)
		cout << *a << endl;
	cout << "\n=======================================================================================================" << endl;
}

void initHeaders () {
	insert (header, "iostream");
	insert (header, "vector");
	insert (header, "fstream");
	insert (header, "stdio.h");
}

void initKeywords () {
	insert (keyword, "#include");
	insert (keyword, "#define");
	insert (keyword, "using");
	insert (keyword, "namespace");
	insert (keyword, "std");
	insert (keyword, "int");
	insert (keyword, "float");
	insert (keyword, "string");
	insert (keyword, "char");
	insert (keyword, "if");
	insert (keyword, "else");
	insert (keyword, "case");
	insert (keyword, "default");
	insert (keyword, "switch");
	insert (keyword, "struct");
	insert (keyword, "return");
	insert (keyword, "void");
	insert (keyword, "cout");
	insert (keyword, "cin");
	insert (keyword, "::");
	insert (keyword, "long");
	insert (keyword, "bool");
	insert (keyword, "scanf");
	insert (keyword, "printf");
	insert (keyword, "for");
}

void initDatatypes () {
        insert (datatypes, "int");
	insert (datatypes, "float");
	insert (datatypes, "char");
	insert (datatypes, "string");
	insert (datatypes, "double");
	insert (datatypes, "void");
	insert (datatypes, "bool");

}
void initOperators () {
//	int x;
	insert (operators, "+");
//	cin >> x;
	insert (operators, "-");
//	cin >> x;
	insert (operators, "*");
//	cin >> x;
//	insert (operators, "/");
//	cin >> x;
	insert (operators, "++");
	insert (operators, "--");
	insert (operators, "+=");
	insert (operators, "-=");
	insert (operators, "=");
	insert (operators, "*=");
	insert (operators, "!=");
	insert (operators, "==");
	insert (operators, "%");
	insert (operators, "^");
	insert (operators, "&");
	insert (operators, "|");
	insert (operators, "&&");
	insert (operators, "||");
	insert (operators, "<<");
	insert (operators, ">>");
	insert (operators, ">=");
	insert (operators, "<=");
	insert (operators, "<");
	insert (operators, ">");
//	cin >> x;
}

void initBrackets () {
	insert (brackets, "(");
	insert (brackets, ")");
	insert (brackets, "{");
	insert (brackets, "}");
	insert (brackets, "[");
	insert (brackets, "]");
	insert (brackets, "<");
	insert (brackets, ">");
	insert (brackets, "()");
	insert (brackets, "[]");
	insert (brackets, "<>");
	insert (brackets, "{}");
}

vector <string> string_vector;

bool varCheck (string str) {
	if (str != "   " && str.substr (0,1) != "0" && str.substr (0,1) != "1" && str.substr (0,1) != "2" &&str.substr (0,1) != "3" &&str.substr (0,1) != "4" &&str.substr (0,1) != "5" &&str.substr (0,1) != "6" &&str.substr (0,1) != "7" &&str.substr (0,1) != "8" &&str.substr (0,1) != "9" ) {
		if (str.find (",") != std::string::npos || str.find ("\"") != std::string::npos || str.find ("(") != std::string::npos || str.find (")") != std::string::npos || str.find ("[") != std::string::npos || str.find ("[") != std::string::npos || str.find ("?") != std::string::npos || str.find ("#") != std::string::npos || str.find ("@") != std::string::npos|| str.find (":") != std::string::npos)
		       return false;
		else
			return true;
	}
	else
		return false;
}

int main () {

	initKeywords ();
	initOperators ();
	initHeaders ();
	initBrackets ();
	initDatatypes ();

	int A = 0, B = 0, C = 0, D = 0, variable_type_keeper_size = -1;
	ifstream file,file2;
	file.open (".temp.dat");
	file2.open("inpu.txt");

	if (!file)
		exit (-1);
	string text = "", temp, variable_type_keeper = "NULLSTR";
	string output="";
	while (!file.eof ()) {
		getline (file, temp);
		text.append (temp);
	}

	file.close ();
	int x;

	string buf;
	stringstream ss (text);

	while (ss >> buf)
		string_vector.push_back (buf);
	int tok_c = 0;
	fstream f,f2;

	f.open ("token.list",ios::out|ios::app);
	f2.open("inp.txt",ios::out|ios::app);
	for (auto ai = string_vector.begin (); ai != string_vector.end (); ai++, tok_c++) {
		string str = *ai;
		f << "<" << str << "," << tok_c << ">" << endl;
		if (search (keyword, str)) {
			cout << str.substr (0,str.find (";") - 1) << "\t\tKEYWORD" << endl;
			if (search (datatypes, str)) {
				variable_type_keeper = str;
				if (str == "int")
					variable_type_keeper_size = 4;
				else if (str == "float")
					variable_type_keeper_size = 8;
				else if (str == "char")
					variable_type_keeper_size = 1;
				else if (str == "string")
					variable_type_keeper_size = str.length ();
				else if (str == "bool")
					variable_type_keeper_size = 1;
				else if (str == "void")
					variable_type_keeper_size = 4;
				else if (str == "bool")
					variable_type_keeper_size = 1;
				else if (str == "double")
					variable_type_keeper_size = 8;

			}
			if (search (datatypes, str))
			output.append("type ");
			else{
			output.append(str.substr (0,str.find (";") - 1));
			output.append(" ");
		}
		}
		else if (search (operators, str)){
			cout << str << "\t\tOPERATOR" << endl;
			if(str==">" || str=="<" || str=="=="|| str==">=" || str=="<=") 
			output.append("cond_op ");
			else if(str=="++" || str=="--"){
			output.append(str);
			output.append(" ");
		}
		else
			output.append("op ");
		}
		else if (search (brackets, str) || search (brackets, str.substr (0,str.length () - 1))) {
			cout << str.substr (0, str.find (";")) << "\t\tBRACKET" << endl;
			output.append(str.substr (0, str.find (";")));
			output.append(" ");
			if (str == "(")
				A++;
			else if (str == ")" || str == ");")
				A--;
			else if (str == "{")
				B++;
			else if (str == "}" || str == "};")
				B--;
			else if (str == "[")
				C++;
			else if (str == "]" || str == "];")
				C--;
			else if (str == "<")
				D++;
			else if (str == ">" || str == ">;")
				D--;
			if (str.find (";") != std::string::npos){
				cout << ";\t\tDELIMITER" << endl;
				output.append("; ");
			}
			}
		else if (search (keyword, str.substr (0,str.length ()-1)) && str != "") {
			if (str.find (";") != std::string::npos) {
				cout << str.substr (0, str.find (";")) << "\t\tKEYWORD" << endl;
				if (search (datatypes, str.substr (0, str.find (";"))))
				output.append("type ");
				else{
				output.append(str.substr (0, str.find (";")));
				output.append(" ");
			}
				cout << ";\t\tDELIMITER" << endl;
				output.append("; ");

			}
			else{
				cout << str << "\t\tKEYWORD" << endl;
				if (search (datatypes, str))
				output.append("type ");
				else{
				output.append(str);
				output.append(" ");

			}

			}
			if ((search (datatypes,  str.substr (0,str.length ()-1))) && str != "") {
				variable_type_keeper = str.substr (0,str.length ()-1);
				if (str.substr (0,str.length ()-1) == "int")
					variable_type_keeper_size = 4;
				else if (str.substr (0,str.length ()-1) == "float")
					variable_type_keeper_size = 8;
				else if (str.substr (0,str.length ()-1) == "char")
					variable_type_keeper_size = 1;
				else if (str.substr (0,str.length ()-1)  == "string")
					variable_type_keeper_size = str.length ()-1;
				else if (str.substr (0,str.length ()-1) == "bool")
					variable_type_keeper_size = 1;
				else if (str.substr (0,str.length ()-1) == "void")
					variable_type_keeper_size = 4;
			}
		}
		else if (search (header, str.substr (1,str.length ()-2)) && str != "")
			cout << str << "\t\tHEADER" << endl;
		else {
			if (str == ","){
				cout << str << "\t\tDELIMITER" << endl;
				output.append(str);
				output.append(" ");
			}
			else if (str == "/" || str == "/=")
			       cout << str << "\t\tOPERATOR" << endl;
			else if (varCheck (str)) {
				if (str.find (";") >= 0 && str.find (";") <= str.length ()) {
				//	cout << str.substr (0, str.find (";")) << "\t\tVARIABLE" << endl;
					cout << ";\t\tDELIMITER" << endl;
					output.append("; ");
			//		if (variable_type_keeper != "NULLSTR")
					if (str[0] != '*' && str[0] != '&')
						symbolTableMethod (str.substr (0,str.length ()-1), variable_type_keeper, to_string (variable_type_keeper_size));
					else
						symbolTableMethod (str.substr (1,str.length ()-1), variable_type_keeper, to_string (variable_type_keeper_size));
					variable_type_keeper_size = -1;
					variable_type_keeper = "NULLSTR";
				}
				else {
					cout << str << "\t\tVARIABLE" << endl;
					output.append("id ");
//					if (variable_type_keeper != "NULLSTR")
					if (str[0] != '*' && str[0] != '&')
						symbolTableMethod (str, variable_type_keeper, to_string (variable_type_keeper_size));
					else
						symbolTableMethod (str.substr (1,str.length ()-1), variable_type_keeper, to_string (variable_type_keeper_size));
				}
			}
			else {
				if (str.find (".") >= 0 && str.find (".") <= str.length () && str.find ("\"") == std::string::npos) {
					if (str.find (";") >= 0 && str.find (";") <= str.length ()) {
						string strB = str;
						strB.erase (0, str.find (".")+1);
						if (strB.find (".") != std::string::npos) {
							cout << str.substr (0, str.find (";")) << "\t\tINVALID!" << endl;
						}
						else {
							cout << str.substr (0, str.find (";")) << "\t\tFLOAT" << endl;
							output.append("lit ");
						}
						cout << ";\t\tDELIMITER" << endl;
						output.append("; ");
					}
					else {
						string strB = str;
						strB.erase (0, str.find ("."));
						if (strB.find (".") == std::string::npos) {
							cout << str.substr (0, str.find (";")) << "\t\tINVALID!" << endl;
						}
						else {
							cout << str << "\t\tFLOAT";
							output.append("lit ");
						}
					}
				}
				else if (str.find ("\"") >= 0 && str.find ("\"") <= str.length ()) {
					for(char& c : str) {
						if (c != ';') {
						        if (c != '`')
								cout << c;
							else
								cout << " ";
						}
					}
					cout << "\t\tSTRING" << endl;
					if (str.find (";") != std::string::npos)
							cout << ";\t\tDELIMITER" << endl;
							output.append("; ");

				}
				else {
					if (str.find (";") >= 0 && str.find (";") <= str.length ()) {
						cout << str.substr (0, str.find (";")) << "\t\tINTEGER" << endl;
						output.append("lit ");
						cout << ";\t\tDELIMITER" << endl;
						output.append("; ");
					}
					else
						cout << str << "\t\tINTEGER" << endl;
						output.append("lit ");
				}
			}
		}
	}

	symbolTablePrinter ();
	if (A != 0 || B != 0 || C != 0 || D != 0)
		cout << "The Number of brackets mismatch!" << A << " " << B << " " << C << endl;

	f.close ();

//	cout << "\n\nOutput file generated as token.list" << endl;


	cout<<"\n\n\n This will be the input for the next LL1 parse ....\n\n"<<output<<endl;
	f2<<output;
	return 1;
}
