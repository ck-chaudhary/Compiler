import sys
def main ():
	x = '' 
	in_file = open (sys.argv[1])
	string = in_file.read ()
	in_file.close ()
	out_file = open (".temp.dat","w")
	words = string.split ('\n')
	flag = 0
	counter = 0
	for i in words:
		x = ''
		if '/*' in i:
			   flag = 1
		if flag == 0 and '//' not in i:	
			if '"' in i:
		       		string_words = i.split ('"')
				counter = 0
				for j in string_words:
					if counter%2 == 0:
						out_file.write (j + ' ')
					if counter%2 == 1:
						k = j.split (' ')
						l = '"'
						for kk in k:
							l = l + kk + '`'
						l = l[0:-1] + '"'
						if counter < len (string_words) - 2:
							out_file.write (l + ' ')
						else:
							out_file.write (l)
					counter = counter + 1
			else:
				out_file.write (i+" ")			
		if '*/' in i:
			flag = 0
		if '//' in i and '"' not in i:
			out_file.write (i[0:i.find ('//')]+" ")
	out_file.close ()
try:
	main ()
except IndexError:
	print '[USAGE]\t$ ./launcher.sh [filename]'
