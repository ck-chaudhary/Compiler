#include<iostream>
#include<fstream>
using namespace std;
int main()
{
  ifstream f("input3.txt");
  string line,rd;
  int pos1,pos2;
  int reg_count=0;
  int local_reg_no=1,final_local_reg_no=0;

  while(!f.eof()){
  getline(f,line);
  //cout<<line<<endl;
//  cout<<"Bsi_block pos "<<line.find("Basic_block")<<endl;
if(line.find("Basic_block") >= 0 && line.find("Basic_block")<1000){
    cout<<"\n\nTotal Register used in this block = "<<reg_count-local_reg_no<<"\nNON-Increasing order of these registers "<<endl;
    final_local_reg_no=reg_count;
    for(int i=final_local_reg_no;i>local_reg_no;i--)
    cout<<" R"<<i-1<<endl;
    cout<<"\n"<<endl;
    local_reg_no=final_local_reg_no;
  }
else if(line.find("goto")>0 && line.find("goto")<1000)
  {     pos1=line.find("(");
	pos2=line.find(")");
	//cout<< "pos1="<<pos1<<",pos2="<<pos2<<endl;
	rd=line.substr(pos1+1,pos2-pos1-1);
	cout<< "jal R"<<reg_count++<<" "<<rd <<endl;
  }
  else if(line.find("if")>0 && line.find("if")<1000)
  {
	if(line.find(">=")>0 && line.find(">=")<1000)
	{
		pos1=line.find("if");
		pos2=line.find(">=");
		rd=line.substr(pos1+3,pos2-pos1-3);
		cout<<"bge "<<rd<<" 50"<<endl;
		//cout << "greater than "<<rd <<endl;
	}
	else if(line.find("!=")>0 && line.find("!=")<1000)
	{
		pos1=line.find("if");
		pos2=line.find("!=");
		rd=line.substr(pos1+3,pos2-pos1-3);
		cout << "bne "<<rd << " 0"<<endl;
	}
  }
  else if(line.find("[")>=0 && line.find("[")<1000)
  {

  }
  else if(line.find("return")>0 && line.find("return")<1000)
{
pos1=line.find(":");
line=line.substr(pos1+2);
cout<<line<<endl;
break;
}
  else
  {
    string subs,r1,r2;
    int eq=line.find("="),i;

    rd=line.substr(0,eq);

    pos1=rd.find(":");
    rd=rd.substr(pos1+1);
   //cout<<"rd = "<<rd<<endl;
    line=line.substr(eq+1);
    //cout<<"line in btw= "<<line<<endl;
    if((line.find("+")>0 && line.find("+")<1000) || (line.find("-")>0 && line.find("-")<1000) || (line.find("*")>0 && line.find("*")<1000)||(line.find("%")>0 && line.find("%")<1000))
    {
      if(line.find("+")>0 && line.find("+")<1000)
      {
        int plus=line.find("+");
        r1=line.substr(0,plus);
      //  cout<<"r1= "<<r1<<endl;
          cout<<"lb R"<<reg_count++<<" "<<r1<<endl;
        line=line.substr(plus+1);
        //cout<<"line finally="<<line<<endl;
        int not_num=0;
        for(int i=0;i<line.length();i++)
        {
          if(isdigit(line[i]))
          continue;
          else
          {
          not_num=1;
          break;
          }

        }
        if(not_num==0)
        {
  //        cout<<"its num"<<endl;
          cout<<"addi R"<<reg_count<<" R"<<reg_count-1<<" "<<line<<endl;
          reg_count+=1;
        }
        else
        {
	  cout<<"lb R"<<reg_count++<<" "<<line<<endl;
	  cout<<"add R"<<reg_count<<" R"<<reg_count-2<<" R"<<reg_count-1<<endl;
        }
        cout<<"st "<<rd<<" R"<<reg_count++<<endl;
      }
	else if(line.find("*")>0 && line.find("*")<1000)
	{
	         int mul=line.find("*");
        	r1=line.substr(0,mul);
      cout<<"lb R"<<reg_count++<<" "<<r1<<endl;
		line=line.substr(mul+1);
		int not_num=0;
        	for(int i=0;i<line.length();i++)
        	{
          	if(isdigit(line[i]))
          	continue;
          	else
          	{
          	not_num=1;
          	break;
          	}

        	}
        	if(not_num==0)
        	{
  //        	cout<<"its num"<<endl;
            cout<<"lb R"<<reg_count++<<" "<<line<<endl;
        	  cout<<"add R"<<reg_count<<" R"<<reg_count-2<<" R"<<reg_count-1<<endl;
		cout<<" #This will be done "<<line<< " times"<< endl;
          	//for(i=1;i<int(line);i++)

        	}
		else
		{
      cout<<"lb R"<<reg_count++<<" "<<line<<endl;
  	  cout<<"add R"<<reg_count<<" R"<<reg_count-2<<" R"<<reg_count-1<<endl;
		cout<<" #This will be done "<<line<< " times"<< endl;
		//for(i=1;i<int(line);i++)

		}
        cout<<"st "<<rd<<" R"<<reg_count++<<endl;
	}
	else if(line.find("-")>0 && line.find("-")<1000)
      {
        int minus=line.find("-");
        r1=line.substr(0,minus);
      //  cout<<"r1= "<<r1<<endl;
          cout<<"lb R"<<reg_count++<<" "<<r1<<endl;
        line=line.substr(minus+1);
        //cout<<"line finally="<<line<<endl;
        int not_num=0;
        for(int i=0;i<line.length();i++)
        {
          if(isdigit(line[i]))
          continue;
          else
          {
          not_num=1;
          break;
          }

        }
        if(not_num==0)
        {
//          cout<<"its num"<<endl;
          cout<<"subi R"<<reg_count<<" R"<<reg_count-1<<" "<<line<<endl;
          reg_count+=1;
        }
        else
        {
          cout<<"lb R"<<reg_count++<<" "<<line<<endl;
      	  cout<<"sub R"<<reg_count<<" R"<<reg_count-2<<" R"<<reg_count-1<<endl;
        }
        cout<<"st "<<rd<<" R"<<reg_count++<<endl;
      }
      	else if(line.find("%")>0 && line.find("%")<1000)
	{
	         int mod=line.find("%"),res;
        	r1=line.substr(0,mod);
      cout<<"lb R"<<reg_count++<<" "<<r1<<endl;
		line=line.substr(mod+1);
		string str1=line;
		int not_num=0;
        	for(int i=0;i<line.length();i++)
        	{
          	if(isdigit(line[i]))
          	continue;
          	else
          	{
          	not_num=1;
          	break;
          	}

        	}
        	if(not_num==0)
        	{
  //        	cout<<"its num"<<endl;
            cout<<"lb R"<<reg_count++<<" "<<line<<endl;
        	  cout<<"sub R"<<reg_count<<" R"<<reg_count-2<<" R"<<reg_count-1<<endl;
		cout<< " #this will be done until result is not less than "<<line<<endl;
		//res=int(r1)-int(str1);
          	//while(res>int(str1))
		//{


		//res=int(r1)-int(str1);
		//}
        	}
		else
		{
      cout<<"lb R"<<reg_count++<<" "<<line<<endl;
  	  cout<<"sub R"<<reg_count<<" R"<<reg_count-2<<" R"<<reg_count-1<<endl;
		cout<< " #this will be done until result is not less than "<<line<<endl;

		/*res=int(r1)-int(str1);
		while(res>int(str1))
		{
		cout<<"sub R1 R1 R2"<<endl;
		}*/
		}
        cout<<"st "<<rd<<" R"<<reg_count++<<endl;
	}

    }
    	else
	{
      cout<<"lb R"<<reg_count++<<" "<<line<<endl;
cout<<"st "<<rd<<" R"<<reg_count++<<endl;
	}

  }
}
}
