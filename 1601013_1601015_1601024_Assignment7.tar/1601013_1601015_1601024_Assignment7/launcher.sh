g++ tem.cpp
./a.out
g++ basic_block.cpp
./a.out
g++ reg.cpp
./a.out
