#include<iostream>
#include<cstdlib>
#include<vector>
#include<fstream>
#include<cstring>
#include<algorithm>
#include<set>
using namespace std;

struct basic_block
{
  string inst[20];
  int inst_count;
  struct basic_block *direct_flow;
  struct basic_block *indirect_flow;
};

int main()
{

vector<string> v;
  ifstream in("input2.txt");

  if(!in) {
    cout << "Cannot open input file.\n";
    return 1;
  }
  char str[255];
  int i=0;
  while(in) {
    in.getline(str, 255);  // delim defaults to '\n'
//    if(in)
//    cout << str << endl;
  v.push_back(str);

  }

  // for(int j=0;j<v.size();j++)
  // cout<<v[j]<<endl;

  //finding out leaders
  vector<string> leaders;
  for(i=0;i<v.size();i++)
  {
    if(i==0)
    {
      leaders.push_back(v[i]);
               //cout<<"Leader found:"<<v[i]<<endl;
    }
    else
    {
  //   char *token;
    // strcpy(token,v[i]);
  //   cout<<token;
  // cout<<v[i]<<" "<<v[i].substr(3,4)<<endl;
  //   cout<<v[i]<<endl;
  int pos=v[i].find("if");
  int gpos=v[i].find("goto");
  cout<<"if at "<<pos<<"goto at "<<gpos<<endl;
       if(pos > 0 || gpos > 0)
       {
         //cout<<"Leader found1:"<<v[i]<<endl;
         int goto_pos=v[i].find("goto");
      string bran_pos=v[i].substr(goto_pos+4);
         //cout<<"after Goto:"<<bran_pos<<endl;
         int open_pos=bran_pos.find("(");
         int close_pos=bran_pos.find(")");
         string new_num=bran_pos.substr(open_pos+1,close_pos-2);
         //cout<<"final pos:"<<new_num<<endl;

        for(int k=0;k<v.size();k++)
        {
          int pos_colon=v[k].find(":");
          //cout<<"pos_colon:"<<pos_colon<<" "<<v[k].substr(0,pos_colon)<<endl;
          //cout<<"comparing"<<new_num<<" "<<v[k].substr(0,pos_colon-1)<<"y is this"<<endl;
          string pos_lead=v[k].substr(0,pos_colon-1);
          if( new_num.compare(pos_lead)==0)
          {
            leaders.push_back(v[k]);
               //cout<<"Leader found2:"<<v[k]<<endl;
          }
        }
    //    sort(leaders,leaders+leaders.size());
        leaders.push_back(v[i+1]);
       }

    }
  }

set<string> st;
cout<<"All leaders are:"<<endl;
  for(i=0;i<leaders.size();i++){
    st.insert(leaders[i]);
    cout<<leaders[i]<<endl;
  }

cout<<endl;

  //st.insert(leaders,leaders+leaders.size());
   set<string>::iterator it1,it2;
  for (it1 = st.begin(); it1!=st.end();  ++it1)
    cout << *it1 << endl;
in.close();

ifstream in2("input2.txt");

if(!in2) {
  cout << "Cannot open input file.\n";
  return 1;
}
struct basic_block *bblock;
bblock=new basic_block[st.size()];
int bb_count=0;

while(in2) {
  in2.getline(str, 255);
  cout<<str<<endl;

  it2 = st.find(str);
  if(it2!=st.end()){
      cout<<"pos= "<<*it2<<endl;
      bblock[bb_count].inst_count=0;
      bblock[bb_count].inst[bblock[bb_count].inst_count++]=str;
      bb_count++;
  }
  else
  bblock[bb_count-1].inst[bblock[bb_count-1].inst_count++]=str;
}

ofstream fw;
fw.open("input3.txt");
cout<<"\n\n"<<endl;
for(int i=0;i<bb_count;i++){
  cout<<"\n\nBasic Block "<<i+1<<endl;
  fw<<"Basic_block"<<endl;
  for(int j=0;j<bblock[i].inst_count;j++){
    cout<<bblock[i].inst[j]<<endl;
    fw<<bblock[i].inst[j]<<endl;
  }
  fw<<"\n"<<endl;
  cout<<"\n"<<endl;
}




  return 0;

}
