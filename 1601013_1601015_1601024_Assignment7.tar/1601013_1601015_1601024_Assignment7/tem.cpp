#include<iostream>
#include<fstream>
#include<sstream>
#include <string>
#include<stack>
#include"postfix_conversion.cpp"
using namespace std;
int main(){
string line;
int line_count=1;
ifstream f("input.txt");
ofstream fw;
fw.open("output.txt");
int tem_used=1;
if(f.is_open()){
while(!f.eof()){
getline(f,line);
cout<<"\n"<< line<<endl;
if(line.find(';') < 1000){
  cout<<"printing in file\n"<<line.find(";")<<endl;
  if(line.find('=') < 1000 && line.size() < 9){
  int p=line.find(";");
  string st1=line.substr(0,p);
  fw<<line_count++<<": "<<st1<<endl;
}
}
// if(line[0:2] == 'if') {
//
// } else if(line[0:3] == 'for') {
//
// } else if(line[0:4] == 'else'){
//
// } else {
  // c= 45;
  // c = a + b * c;
  // c++;
  int len = line.length();
  int temp = 0;
  while(len--) {
    if(line[len] == '+' || line[len] == '-' || line[len] == '*' || line[len] == '/' || line[len] == '%') {
      if(line[len -1] == '+' || line[len-1] == '-') {
        continue;
      } else {
        temp++;
      }

    }
  }
cout<<"Temporary used will be: "<<temp<<endl;

if(temp > 0)
{
//  fw<<"Temporary used will be: "<<temp<<endl;
  //if for hard code then continue;


if(line.find("for") ==0 ){
  cout<<"\n 3 Address code for FOR LOOP : "<<line<<endl;
//  fw<<"\n 3 Address code for FOR LOOP : ";
//  fw<<line<<endl;
//    cout<<"checking......="<<line.find("+")<<endl;
    int loopc=line.find("+");
  string st =line.substr(line.find("(")+1,loopc+1-line.find("("));
  int p=st.find(";");
  string st1=st.substr(0,p);
  cout<<st1<<endl;
  fw<<line_count++<<": "<<st1<<endl;
  char loop_var=st1[0];
  st=st.substr(p+1);
//  cout<<st<<endl;
  p=st.find(";");
 st1=st.substr(0,p);
st=st.substr(p+1);
 p=st1.find("<");
 st1[p]='>';
cout<<"if "<<st1<<" goto L3"<<endl;
fw<<line_count++<<": "<<"if "<<st1<<" goto ("<<line_count-2<<")"<<endl;
//  cout<<"edited for exp="<<st<<endl;
cout<<"Increment/decrement temporary "<<endl;
//fw<<"Increment/decrement temporary "<<endl;
ostringstream strint;
strint<<tem_used;
tem_used++;
string strc=strint.str();
cout<<"t"<<strc<<"="<<loop_var<<"+1"<<endl;
fw<<line_count++<<": "<<"t"<<strc<<"="<<loop_var<<"+1"<<endl;
cout<<loop_var<<"="<<"t"<<strc<<endl;
fw<<line_count++<<": "<<loop_var<<"="<<"t"<<strc<<endl;
  continue;
}

if(line.find("if") ==0 ){
  cout<<"\n 3 Address code for IF STATEMENT : "<<line<<endl;
  //fw<<"\n 3 Address code for IF STATEMENT : ";
  //fw<<line<<endl;
  string st =line.substr(line.find("(")+1,line.find(")")-line.find("("));
  //cout<<st<<endl;
  string st1=st.substr(0,st.find("="));
  st=st.substr(st.find("="),st.find(")")-st.find("=")-1);
  ostringstream strint;
  strint<<tem_used;
  tem_used++;
  string strc=strint.str();
  cout<<"t"<<strc<<"="<<st1<<endl;
  fw<<line_count++<<": "<<"t"<<strc<<"="<<st1<<endl;
  cout<<"if t"<<strc<<" "<<st<<" goto L2"<<endl;
  fw<<line_count++<<": "<<"if t"<<strc<<" "<<st<<" goto ("<<line_count-2<<")"<<endl;   //check level
  continue;
}

cout<<"\n 3 Address code for expression : "<<line<<endl;
//fw<<"\n 3 Address code for expression : ";
//fw<<line<<endl;

stack <string> my_stack;
  char init_var=line[0];
string edited_line=line.substr(line.find("=")+1,line.find(";")-2);
//cout<<"edited_line:"<<edited_line<<endl;
string post_fix=infixToPostfix(edited_line);
//cout<<"new exp="<<post_fix<<endl;
int i=0;
string strc;
while(i < post_fix.length()){
  if(post_fix[i]=='*' || post_fix[i]=='+'||post_fix[i]=='-'||post_fix[i]=='/'||post_fix[i]=='%')
  {
//    cout<<"poping......"<<endl;
    string s1=my_stack.top();
    my_stack.pop();
    string s2=my_stack.top();
    my_stack.pop();
//    cout<<"popped elements are :"<<s2<<"\t"<<s1<<endl;
    cout<<"t"<<tem_used<<"="<<s2<<post_fix[i]<<s1<<endl;
    fw<<line_count++<<": "<<"t"<<tem_used<<"="<<s2<<post_fix[i]<<s1<<endl;

    ostringstream stri;
    stri<<tem_used;
   strc=stri.str();
  //  string stri = to_string(tem_used);
//string pused_var=to_string(tem_used);
//    cout<<"changed pushing string="<<"t"<<strc<<endl;
    my_stack.push("t"+strc);
    tem_used++;
  }
else
{
  string str(1,post_fix[i]);
  my_stack.push(str);
//  cout<<"pushing into stack="<<post_fix[i]<<endl;
}

i++;
}
cout<<init_var<<"=t"<<strc<<endl;
fw<<line_count++<<": "<<init_var<<"=t"<<strc<<endl;

  }


else {
  cout<<line<<endl;
}
  cout <<"Number of temporaries = "<< temp << endl;
//}
}
}
return 0;
}
